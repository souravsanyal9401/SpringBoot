package com.WAR_File;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WarFileApplicationTests {

	@Test
	void contextLoads() {
	}

}
