package com.RestEndpoint;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestEndpointApplicationTests {

	@Test
	void contextLoads() {
	}

}
